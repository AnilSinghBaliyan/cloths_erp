export { ChallanDetail } from "./ChallanDetail";
