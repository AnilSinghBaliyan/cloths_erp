export { FabricDetails } from "./FabricDetails";
