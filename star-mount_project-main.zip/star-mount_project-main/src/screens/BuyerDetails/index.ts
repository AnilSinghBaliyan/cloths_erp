export { BuyerDetails } from "./BuyerDetails";
