export { MasterDetails } from "./MasterDetails";
